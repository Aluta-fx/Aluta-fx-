
# AlutaFx RULESET

## 1. General Rules
- AlutaFx is a community focused on sharing trading knowledge, signals, and strategies.
- Respect all members and maintain professionalism in all interactions.
- No spamming, self-promotion, or sharing of unrelated content.

## 2. Signal Usage
- All signals shared are for educational purposes only.
- Execute trades at your own risk—AlutaFx is not liable for any financial losses.
- Always use proper risk management.

## 3. Trading Rules
- Stick to a maximum of 1-2% risk per trade.
- Avoid trading under emotional pressure (FOMO, revenge trading).
- Wait for confirmation before entering trades.

## 4. Content Sharing
- Do NOT copy or resell AlutaFx signals, strategies, or tutorials without permission.
- Give credit when sharing insights or setups from AlutaFx.

## 5. Community Conduct
- Engage positively and help others grow.
- Report any inappropriate behavior to the admin team.
- Stay on topic—focus on Forex, Gold, Indices, and Prop Firm trading.

## 6. Disclaimer
- Past performance does not guarantee future results.
- AlutaFx provides educational material only.
- Trade responsibly and seek financial advice if needed.

---

**© 2025 AlutaFx - Empowering Traders Worldwide.**
